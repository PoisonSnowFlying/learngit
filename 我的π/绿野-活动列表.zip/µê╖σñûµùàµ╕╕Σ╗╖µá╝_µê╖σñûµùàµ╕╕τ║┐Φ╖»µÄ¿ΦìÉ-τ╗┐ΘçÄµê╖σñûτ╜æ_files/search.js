$(function() {
    getCkDeal();

    //$(".tabs").tabs();

    //$(".tabs2").tabs();

    $('.tabs2 .ac_tab li').live('click',function(){
        tabs($(this));
    })

    $('.hdItem').hover(function(){
        $(this).addClass('hdItemHover');
    },function(){
        $(this).removeClass('hdItemHover');
    })

    $('.hotHdItem').hover(function(){
    	$(this).find('.txt').stop().animate({'bottom': '0px'});
    },function(){
    	$(this).find('.txt').stop().animate({'bottom': '-79px'});
    })

    $('.recommendHd li').hover(function(){
        $(this).find('.txt').stop().animate({'bottom': '0px'});
    },function(){
        $(this).find('.txt').stop().animate({'bottom': '-80px'});
    })

    $('.sfliter .arrow').live('click',function(){
        var $parent = $(this).parents('.sfliter');
        var $sibselect = $parent.siblings('.sfliter').find('.fresult');
        if($sibselect.css('display') == 'block') {
            $sibselect.css('display','none');
        }
        $parent.find('.fresult').slideToggle();
    })

    $(document).click(function(e) {
		var target = $(e.target);
		if (!target.is('.fresult') && !target.parents().is('.fresult') && !target.is('.arrow')) {
			$('.fresult').hide();
		}
	})

	$('.moreFliter .more').live('click',function(){
		var $this = $(this);
		var $p = $this.parents('.moreFliter');
		var $ps = $this.parents('.fgroup').find('.retractFilter');
		$p.hide();
		$ps.show();
		$p.parents('.fgroup').find('.moreFliterBox').show();
	})
	$('.retractFilter .more').live('click',function(){
		var $this = $(this);
		var $s_p = $this.parents('.retractFilter');
		var $s_ps = $this.parents('.fgroup').find('.moreFliter');
		$s_p.hide();
		$s_ps.show();
		$s_p.parents('.fgroup').find('.moreFliterBox').hide();
	})

    $('.fresult a').live('click',function(){
        var cid = $(this).attr('data-cid');
        var val = "{'cid': "+cid+",'cname':'"+$(this).text()+"'}";
        setCookie('_LY_SEARCH_CITY', val, '', '/', 'lvye.com','');
        getCkDeal();
        $("#eventSearchForm input[name='departCity']").val(cid);
        $('.fresult').hide();
    })

    $(document).on("click", ".pagenation ul li", function () {
        if($(this).attr("url") && $(this).attr("url")!=""){
            window.location.href=$(this).attr("url");
        }
    });

    $(document).on("click", ".pagenation .goBtn", function () {
        var page = $(this).attr("page");
        var pageVal = $(this).siblings(".goto").find("input").val();
        var maxPage = $(this).attr("maxPage");
        if (Number(pageVal)&& maxPage>=pageVal) {
            window.location.href=$(this).attr("url")+"&page="+pageVal;
        }
    });

    $(document).on("click","#search-leader-type .fresult p",function(){
       var type = $(this).attr('type');
       if(type==0){
           $("#search-leader-type .f .p").attr("type","0").html("按活动搜索");
           $(this).attr("type","1").html("按领队搜索");
           $("#eventSearchForm input[name='searchType']").val(0);
       }
       if(type==1){
            $("#search-leader-type .f .p").attr("type","1").html("按领队搜索");
            $(this).attr("type","1").attr("type","0").html("按活动搜索");
            $("#eventSearchForm input[name='searchType']").val(1);
       }
       $("#search-leader-type .fresult").slideToggle();
    })

    $('#backtop').click(function() {
        jQuery('html,body').animate({
            scrollTop: 0
        }, 500);
    });

    $('.setTimeDefine').live('click',function(){
        $(this).html('');
        $('.selectSetTime').addClass('selectBox');
    })

    $(".selectSetTime .confirmBtn").click(function(){
       var startDate = $(".selectSetTime input[name='departStartTime']").val();
       var endDate = $(".selectSetTime input[name='departEndTime']").val();
       if((!startDate || startDate == "") && (!endDate || endDate == "")){
          $(".selectSetTime .color-org").html("请选择日期");
          return false;
       }
       $(".selectSetTime").submit();
    });

    $(".selectSetTime input[name='departStartTime'],.selectSetTime input[name='departEndTime']").focus(function(){
        $(".selectSetTime .color-org").html("");
    });
})

function getCkDeal(){
    var ck = getCookie('_LY_SEARCH_CITY');
    var ckJson = eval('(' + ck + ')');
    if(ckJson) {
        $('.s_place .p').html(ckJson.cname);
    }
}
